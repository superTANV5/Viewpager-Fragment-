# ViewpagerFragmentTab

Viewpager+Fragment实现的底部导航栏：


 1. ViewPager通过重写源码，可以实现去除预加载功能

 2. ViewPager禁止滑动

 3. 首页的tab支持双击，实现Activity与Fragment通信.
